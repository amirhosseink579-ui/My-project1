
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

abstract class User {
    protected String userId;
    protected String username;
    protected String password;
    protected String name;

    public User(String userId, String username, String password, String name) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.name = name;
    }

    public boolean checkLogin(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    public String getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public abstract String getRole();

    public String printInfo() {
        return userId + " | " + username + " | " + name + " | " + getRole();
    }
}

class Customer extends User {
    public Customer(String userId, String username, String password, String name) {
        super(userId, username, password, name);
    }

    public String getRole() {
        return "Customer";
    }
}

class SupportAgent extends User {
    private int replyCount;
    private int closedTicketCount;
    private int chatCount;

    public SupportAgent(String userId, String username, String password, String name) {
        super(userId, username, password, name);
        replyCount = 0;
        closedTicketCount = 0;
        chatCount = 0;
    }

    public String getRole() {
        return "SupportAgent";
    }

    public void addReply() {
        replyCount++;
    }

    public void addClosedTicket() {
        closedTicketCount++;
    }

    public void addChat() {
        chatCount++;
    }

    public int getReplyCount() {
        return replyCount;
    }

    public int getClosedTicketCount() {
        return closedTicketCount;
    }

    public int getChatCount() {
        return chatCount;
    }
}

class Admin extends User {
    public Admin(String userId, String username, String password, String name) {
        super(userId, username, password, name);
    }

    public String getRole() {
        return "Admin";
    }
}

class Ticket {
    private static int nextId = 1;
    private int ticketId;
    private String title;
    private String description;
    private String customerId;
    private String customerName;
    private String category;
    private String status;
    private int baseImportance;
    private long createdTime;
    private String supportAnswer;
    private String agentId;

    public Ticket(String title, String description, String customerId, String customerName, String category, int baseImportance) {
        ticketId = nextId;
        nextId++;
        this.title = title;
        this.description = description;
        this.customerId = customerId;
        this.customerName = customerName;
        this.category = category;
        status = "OPEN";
        this.baseImportance = baseImportance;
        createdTime = System.currentTimeMillis();
        supportAnswer = "";
        agentId = "";
    }

    public int calculatePriority(ArrayList<Ticket> allTickets) {
        int priority = baseImportance;

        if (category.equalsIgnoreCase("CRITICAL")) {
            priority += 50;
        }

        if (status.equalsIgnoreCase("OPEN")) {
            priority += 30;
        } else if (status.equalsIgnoreCase("IN_PROGRESS")) {
            priority += 20;
        } else if (status.equalsIgnoreCase("ANSWERED")) {
            priority += 10;
        }

        String text = (title + " " + description).toLowerCase();

        if (text.contains("error")) {
            priority += 10;
        }
        if (text.contains("failed")) {
            priority += 10;
        }
        if (text.contains("urgent")) {
            priority += 10;
        }
        if (text.contains("payment")) {
            priority += 10;
        }
        if (text.contains("login")) {
            priority += 10;
        }

        int openCount = 0;
        for (int i = 0; i < allTickets.size(); i++) {
            Ticket t = allTickets.get(i);
            if (t.getCustomerId().equals(customerId) && !t.getStatus().equalsIgnoreCase("CLOSED")) {
                openCount++;
            }
        }

        if (openCount > 1) {
            priority += openCount * 5;
        }

        return priority;
    }

    public boolean containsKeyword(String keyword) {
        String text = (title + " " + description + " " + category + " " + status + " " + customerName + " " + ticketId).toLowerCase();
        return text.contains(keyword.toLowerCase());
    }

    public void changeStatus(String newStatus) {
        status = newStatus;
    }

    public String toFileString() {
        return ticketId + "|" + title + "|" + description + "|" + customerId + "|" + customerName + "|" + category + "|" + status + "|" + baseImportance + "|" + createdTime + "|" + supportAnswer + "|" + agentId;
    }

    public String toString(ArrayList<Ticket> allTickets) {
        return "Ticket ID: " + ticketId + "\nTitle: " + title + "\nCustomer: " + customerName + "\nCategory: " + category + "\nStatus: " + status + "\nBase Importance: " + baseImportance + "\nPriority: " + calculatePriority(allTickets) + "\nDescription: " + description + "\nAnswer: " + supportAnswer + "\n";
    }

    public int getTicketId() {
        return ticketId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCategory() {
        return category;
    }

    public String getStatus() {
        return status;
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public String getText() {
        return title + " " + description;
    }

    public String getAgentId() {
        return agentId;
    }

    public void answer(String answer, String agentId) {
        supportAnswer = answer;
        this.agentId = agentId;
        status = "ANSWERED";
    }
}

class Message {
    private static int nextId = 1;
    private int messageId;
    private int chatId;
    private String senderId;
    private String receiverId;
    private String text;
    private long time;

    public Message(int chatId, String senderId, String receiverId, String text) {
        messageId = nextId;
        nextId++;
        this.chatId = chatId;
        this.senderId = senderId;
        this.receiverId = receiverId;
        this.text = text;
        time = System.currentTimeMillis();
    }

    public String toFileString() {
        return messageId + "|" + chatId + "|" + senderId + "|" + receiverId + "|" + text + "|" + time;
    }

    public String toString() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "[" + f.format(new Date(time)) + "] " + senderId + " to " + receiverId + ": " + text;
    }

    public String getText() {
        return text;
    }

    public String getSenderId() {
        return senderId;
    }
}

class ChatSession implements Runnable {
    private static int nextId = 1;
    private int chatId;
    private String customerId;
    private String supportAgentId;
    private ArrayList<Message> messages;
    private String status;
    private long lastCustomerMessageTime;
    private boolean running;

    public ChatSession(String customerId, String supportAgentId) {
        chatId = nextId;
        nextId++;
        this.customerId = customerId;
        this.supportAgentId = supportAgentId;
        messages = new ArrayList<Message>();
        status = "ACTIVE";
        lastCustomerMessageTime = System.currentTimeMillis();
        running = true;
    }

    public void addMessage(Message message) {
        messages.add(message);
        if (message.getSenderId().equals(customerId)) {
            lastCustomerMessageTime = System.currentTimeMillis();
        }
    }

    public int getMessageCount() {
        return messages.size();
    }

    public String findMostFrequentWord() {
        HashMap<String, Integer> map = new HashMap<String, Integer>();

        for (int i = 0; i < messages.size(); i++) {
            String[] parts = messages.get(i).getText().toLowerCase().split(" ");
            for (int j = 0; j < parts.length; j++) {
                String w = parts[j].replace(".", "").replace(",", "").replace("!", "").replace("?", "");
                if (w.length() > 0) {
                    if (map.containsKey(w)) {
                        map.put(w, map.get(w) + 1);
                    } else {
                        map.put(w, 1);
                    }
                }
            }
        }

        String best = "";
        int count = 0;

        for (String key : map.keySet()) {
            if (map.get(key) > count) {
                best = key;
                count = map.get(key);
            }
        }

        return best;
    }

    public String toFileString() {
        String s = "CHAT|" + chatId + "|" + customerId + "|" + supportAgentId + "|" + status + "\n";
        for (int i = 0; i < messages.size(); i++) {
            s += messages.get(i).toFileString() + "\n";
        }
        return s;
    }

    public void endChat() {
        status = "CLOSED";
        running = false;
    }

    public void run() {
        while (running) {
            try {
                Thread.sleep(5000);
                long now = System.currentTimeMillis();
                if (status.equals("ACTIVE") && now - lastCustomerMessageTime > 10000) {
                    System.out.println("Warning: Customer is waiting for response");
                }
            } catch (Exception e) {
                running = false;
            }
        }
    }

    public String getChatText() {
        String s = "Chat ID: " + chatId + " Customer: " + customerId + " Agent: " + supportAgentId + " Status: " + status + "\n";
        for (int i = 0; i < messages.size(); i++) {
            s += messages.get(i).toString() + "\n";
        }
        return s;
    }

    public int getChatId() {
        return chatId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getSupportAgentId() {
        return supportAgentId;
    }

    public String getStatus() {
        return status;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }
}

class TicketManager {
    private ArrayList<Ticket> tickets;

    public TicketManager() {
        tickets = new ArrayList<Ticket>();
    }

    public Ticket registerTicket(String title, String description, String customerId, String customerName, String category, int baseImportance) throws Exception {
        if (title == null || title.trim().equals("")) {
            throw new Exception("Ticket title is empty");
        }

        if (baseImportance < 1 || baseImportance > 10) {
            throw new Exception("Base importance must be between 1 and 10");
        }

        Ticket ticket = new Ticket(title, description, customerId, customerName, category, baseImportance);
        tickets.add(ticket);
        saveTickets();
        return ticket;
    }

    public Ticket findById(int id) {
        for (int i = 0; i < tickets.size(); i++) {
            if (tickets.get(i).getTicketId() == id) {
                return tickets.get(i);
            }
        }
        return null;
    }

    public void changeStatus(int id, String status) throws Exception {
        Ticket ticket = findById(id);
        if (ticket == null) {
            throw new Exception("Ticket not found");
        }

        if (!status.equals("OPEN") && !status.equals("IN_PROGRESS") && !status.equals("ANSWERED") && !status.equals("CLOSED")) {
            throw new Exception("Invalid status");
        }

        ticket.changeStatus(status);
        saveTickets();
    }

    public void answerTicket(int id, String answer, SupportAgent agent) throws Exception {
        Ticket ticket = findById(id);
        if (ticket == null) {
            throw new Exception("Ticket not found");
        }

        if (answer == null || answer.trim().equals("")) {
            throw new Exception("Answer is empty");
        }

        ticket.answer(answer, agent.getUserId());
        agent.addReply();
        saveTickets();
    }

    public ArrayList<Ticket> search(String word) {
        ArrayList<Ticket> result = new ArrayList<Ticket>();

        for (int i = 0; i < tickets.size(); i++) {
            if (tickets.get(i).containsKeyword(word)) {
                result.add(tickets.get(i));
            }
        }

        return result;
    }

    public ArrayList<Ticket> sortByPriority() {
        ArrayList<Ticket> list = new ArrayList<Ticket>();

        for (int i = 0; i < tickets.size(); i++) {
            list.add(tickets.get(i));
        }

        for (int i = 0; i < list.size(); i++) {
            for (int j = 0; j < list.size() - 1; j++) {
                Ticket a = list.get(j);
                Ticket b = list.get(j + 1);

                int pa = a.calculatePriority(tickets);
                int pb = b.calculatePriority(tickets);
                boolean change = false;

                if (pb > pa) {
                    change = true;
                } else if (pb == pa && b.getCreatedTime() < a.getCreatedTime()) {
                    change = true;
                } else if (pb == pa && b.getCreatedTime() == a.getCreatedTime() && b.getTicketId() < a.getTicketId()) {
                    change = true;
                }

                if (change) {
                    Ticket temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set(j + 1, temp);
                }
            }
        }

        return list;
    }

    public Ticket findCriticalTicket() {
        if (tickets.size() == 0) {
            return null;
        }

        Ticket best = tickets.get(0);

        for (int i = 1; i < tickets.size(); i++) {
            if (tickets.get(i).calculatePriority(tickets) > best.calculatePriority(tickets)) {
                best = tickets.get(i);
            }
        }

        return best;
    }

    public ArrayList<Ticket> getTickets() {
        return tickets;
    }

    public void saveTickets() {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("tickets.txt"));
            for (int i = 0; i < tickets.size(); i++) {
                writer.write(tickets.get(i).toFileString());
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "File write error");
        }
    }
}

class ChatManager {
    private ArrayList<ChatSession> chats;

    public ChatManager() {
        chats = new ArrayList<ChatSession>();
    }

    public ChatSession startChat(String customerId, String agentId) {
        ChatSession chat = new ChatSession(customerId, agentId);
        chats.add(chat);
        Thread thread = new Thread(chat);
        thread.start();
        saveChats();
        return chat;
    }

    public void addMessage(int chatId, String senderId, String receiverId, String text) throws Exception {
        if (text == null || text.trim().equals("")) {
            throw new Exception("Message is empty");
        }

        ChatSession chat = findChat(chatId);
        if (chat == null) {
            throw new Exception("Chat not found");
        }

        Message message = new Message(chatId, senderId, receiverId, text);
        chat.addMessage(message);
        saveChats();
    }

    public void endChat(int chatId) throws Exception {
        ChatSession chat = findChat(chatId);
        if (chat == null) {
            throw new Exception("Chat not found");
        }

        chat.endChat();
        saveChats();
    }

    public ChatSession findChat(int chatId) {
        for (int i = 0; i < chats.size(); i++) {
            if (chats.get(i).getChatId() == chatId) {
                return chats.get(i);
            }
        }
        return null;
    }

    public ArrayList<ChatSession> getChats() {
        return chats;
    }

    public void saveChats() {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("chats.txt"));
            for (int i = 0; i < chats.size(); i++) {
                writer.write(chats.get(i).toFileString());
            }
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Chat file write error");
        }
    }
}

class DashboardManager {
    private ArrayList<User> users;
    private TicketManager ticketManager;
    private ChatManager chatManager;

    public DashboardManager(ArrayList<User> users, TicketManager ticketManager, ChatManager chatManager) {
        this.users = users;
        this.ticketManager = ticketManager;
        this.chatManager = chatManager;
    }

    public String allUsers() {
        String s = "";
        for (int i = 0; i < users.size(); i++) {
            s += users.get(i).printInfo() + "\n";
        }
        return s;
    }

    public String ticketReport() {
        ArrayList<Ticket> tickets = ticketManager.getTickets();
        int open = 0;
        int closed = 0;
        int technical = 0;
        int financial = 0;
        int account = 0;
        int general = 0;
        int critical = 0;

        for (int i = 0; i < tickets.size(); i++) {
            Ticket t = tickets.get(i);

            if (t.getStatus().equals("OPEN") || t.getStatus().equals("IN_PROGRESS") || t.getStatus().equals("ANSWERED")) {
                open++;
            }

            if (t.getStatus().equals("CLOSED")) {
                closed++;
            }

            if (t.getCategory().equals("TECHNICAL")) {
                technical++;
            }
            if (t.getCategory().equals("FINANCIAL")) {
                financial++;
            }
            if (t.getCategory().equals("ACCOUNT")) {
                account++;
            }
            if (t.getCategory().equals("GENERAL")) {
                general++;
            }
            if (t.getCategory().equals("CRITICAL")) {
                critical++;
            }
        }

        Ticket ct = ticketManager.findCriticalTicket();
        String criticalText = "None";
        if (ct != null) {
            criticalText = String.valueOf(ct.getTicketId());
        }

        return "Total tickets: " + tickets.size() + "\nOpen tickets: " + open + "\nClosed tickets: " + closed + "\nTECHNICAL: " + technical + "\nFINANCIAL: " + financial + "\nACCOUNT: " + account + "\nGENERAL: " + general + "\nCRITICAL: " + critical + "\nMost critical ticket: " + criticalText + "\nCustomer with most open tickets: " + customerWithMostOpenTickets() + "\nMost frequent word: " + mostFrequentWord() + "\n";
    }

    public String chatReport() {
        ArrayList<ChatSession> chats = chatManager.getChats();
        ChatSession longest = null;

        for (int i = 0; i < chats.size(); i++) {
            if (longest == null || chats.get(i).getMessageCount() > longest.getMessageCount()) {
                longest = chats.get(i);
            }
        }

        String longestText = "None";
        if (longest != null) {
            longestText = "Chat " + longest.getChatId() + " with " + longest.getMessageCount() + " messages";
        }

        return "Total chats: " + chats.size() + "\nLongest chat: " + longestText + "\n";
    }

    public String supportReport() {
        String s = "";

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i) instanceof SupportAgent) {
                SupportAgent a = (SupportAgent) users.get(i);
                s += a.getName() + " | Replies: " + a.getReplyCount() + " | Closed tickets: " + a.getClosedTicketCount() + " | Chats: " + a.getChatCount() + "\n";
            }
        }

        return s;
    }

    public String highRiskCustomer() {
        int bestScore = -1;
        String bestCustomer = "None";

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i) instanceof Customer) {
                User c = users.get(i);
                int open = 0;
                int critical = 0;
                int sensitive = 0;

                ArrayList<Ticket> tickets = ticketManager.getTickets();

                for (int j = 0; j < tickets.size(); j++) {
                    Ticket t = tickets.get(j);

                    if (t.getCustomerId().equals(c.getUserId())) {
                        if (!t.getStatus().equals("CLOSED")) {
                            open++;
                        }

                        if (t.getCategory().equals("CRITICAL")) {
                            critical++;
                        }

                        String text = t.getText().toLowerCase();
                        if (text.contains("error")) {
                            sensitive++;
                        }
                        if (text.contains("failed")) {
                            sensitive++;
                        }
                        if (text.contains("urgent")) {
                            sensitive++;
                        }
                        if (text.contains("payment")) {
                            sensitive++;
                        }
                        if (text.contains("login")) {
                            sensitive++;
                        }
                    }
                }

                int score = open * 3 + critical * 5 + sensitive;

                if (score > bestScore) {
                    bestScore = score;
                    bestCustomer = c.getName() + " score: " + score;
                }
            }
        }

        return bestCustomer;
    }

    public String customerWithMostOpenTickets() {
        int bestCount = -1;
        String bestName = "None";

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i) instanceof Customer) {
                int count = 0;
                for (int j = 0; j < ticketManager.getTickets().size(); j++) {
                    Ticket t = ticketManager.getTickets().get(j);
                    if (t.getCustomerId().equals(users.get(i).getUserId()) && !t.getStatus().equals("CLOSED")) {
                        count++;
                    }
                }

                if (count > bestCount) {
                    bestCount = count;
                    bestName = users.get(i).getName();
                }
            }
        }

        return bestName;
    }

    public String mostFrequentWord() {
        HashMap<String, Integer> map = new HashMap<String, Integer>();

        for (int i = 0; i < ticketManager.getTickets().size(); i++) {
            String[] parts = ticketManager.getTickets().get(i).getText().toLowerCase().split(" ");
            for (int j = 0; j < parts.length; j++) {
                String w = parts[j].replace(".", "").replace(",", "").replace("!", "").replace("?", "");
                if (w.length() > 0) {
                    if (map.containsKey(w)) {
                        map.put(w, map.get(w) + 1);
                    } else {
                        map.put(w, 1);
                    }
                }
            }
        }

        for (int i = 0; i < chatManager.getChats().size(); i++) {
            ArrayList<Message> messages = chatManager.getChats().get(i).getMessages();
            for (int j = 0; j < messages.size(); j++) {
                String[] parts = messages.get(j).getText().toLowerCase().split(" ");
                for (int k = 0; k < parts.length; k++) {
                    String w = parts[k].replace(".", "").replace(",", "").replace("!", "").replace("?", "");
                    if (w.length() > 0) {
                        if (map.containsKey(w)) {
                            map.put(w, map.get(w) + 1);
                        } else {
                            map.put(w, 1);
                        }
                    }
                }
            }
        }

        String best = "None";
        int count = 0;

        for (String key : map.keySet()) {
            if (map.get(key) > count) {
                best = key;
                count = map.get(key);
            }
        }

        return best;
    }
}

class DataStore {
    public static ArrayList<User> users = new ArrayList<User>();
    public static TicketManager ticketManager = new TicketManager();
    public static ChatManager chatManager = new ChatManager();
    public static DashboardManager dashboardManager = new DashboardManager(users, ticketManager, chatManager);

    static {
        users.add(new Customer("C1", "customer", "1234", "Ali Customer"));
        users.add(new Customer("C2", "mina", "1234", "Mina Customer"));
        users.add(new SupportAgent("S1", "agent", "1234", "Sara Agent"));
        users.add(new SupportAgent("S2", "reza", "1234", "Reza Agent"));
        users.add(new Admin("A1", "admin", "1234", "Admin User"));
    }

    public static User login(String username, String password) throws Exception {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).checkLogin(username, password)) {
                return users.get(i);
            }
        }
        throw new Exception("Wrong username or password");
    }

    public static SupportAgent firstAgent() {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i) instanceof SupportAgent) {
                return (SupportAgent) users.get(i);
            }
        }
        return null;
    }
}

class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginFrame() {
        setTitle("CRM Login");
        setSize(350, 180);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 2));

        add(new JLabel("Username"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Password"));
        passwordField = new JPasswordField();
        add(passwordField);

        JButton loginButton = new JButton("Login");
        add(new JLabel(""));
        add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String username = usernameField.getText();
                    String password = new String(passwordField.getPassword());
                    User user = DataStore.login(username, password);
                    dispose();

                    if (user instanceof Customer) {
                        new CustomerFrame((Customer) user).setVisible(true);
                    } else if (user instanceof SupportAgent) {
                        new AgentFrame((SupportAgent) user).setVisible(true);
                    } else if (user instanceof Admin) {
                        new AdminFrame((Admin) user).setVisible(true);
                    } else {
                        throw new Exception("Invalid role");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(LoginFrame.this, ex.getMessage());
                }
            }
        });
    }
}

class CustomerFrame extends JFrame {
    private Customer customer;
    private JTextArea area;

    public CustomerFrame(Customer customer) {
        this.customer = customer;

        setTitle("Customer Panel");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        area = new JTextArea();
        add(new JScrollPane(area), BorderLayout.CENTER);

        JPanel panel = new JPanel(new GridLayout(2, 3));

        JButton newTicketButton = new JButton("New Ticket");
        JButton myTicketsButton = new JButton("My Tickets");
        JButton startChatButton = new JButton("Start Chat");
        JButton chatHistoryButton = new JButton("Chat History");
        JButton logoutButton = new JButton("Logout");

        panel.add(newTicketButton);
        panel.add(myTicketsButton);
        panel.add(startChatButton);
        panel.add(chatHistoryButton);
        panel.add(logoutButton);

        add(panel, BorderLayout.SOUTH);

        newTicketButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createTicket();
            }
        });

        myTicketsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showMyTickets();
            }
        });

        startChatButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startChat();
            }
        });

        chatHistoryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showChatHistory();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });
    }

    private void createTicket() {
        try {
            String title = JOptionPane.showInputDialog(this, "Title");
            String description = JOptionPane.showInputDialog(this, "Description");
            String[] categories = {"TECHNICAL", "FINANCIAL", "ACCOUNT", "GENERAL", "CRITICAL"};
            String category = (String) JOptionPane.showInputDialog(this, "Category", "Category", JOptionPane.QUESTION_MESSAGE, null, categories, categories[0]);
            String importanceText = JOptionPane.showInputDialog(this, "Base importance 1-10");
            int importance = Integer.parseInt(importanceText);

            DataStore.ticketManager.registerTicket(title, description, customer.getUserId(), customer.getName(), category, importance);
            JOptionPane.showMessageDialog(this, "Ticket created");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void showMyTickets() {
        String s = "";
        ArrayList<Ticket> tickets = DataStore.ticketManager.getTickets();

        for (int i = 0; i < tickets.size(); i++) {
            if (tickets.get(i).getCustomerId().equals(customer.getUserId())) {
                s += tickets.get(i).toString(tickets) + "\n";
            }
        }

        area.setText(s);
    }

    private void startChat() {
        try {
            SupportAgent agent = DataStore.firstAgent();

            if (agent == null) {
                throw new Exception("No support agent found");
            }

            ChatSession chat = DataStore.chatManager.startChat(customer.getUserId(), agent.getUserId());
            agent.addChat();

            String text = JOptionPane.showInputDialog(this, "Your message");
            DataStore.chatManager.addMessage(chat.getChatId(), customer.getUserId(), agent.getUserId(), text);

            JOptionPane.showMessageDialog(this, "Chat started. Chat ID: " + chat.getChatId());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void showChatHistory() {
        String s = "";
        ArrayList<ChatSession> chats = DataStore.chatManager.getChats();

        for (int i = 0; i < chats.size(); i++) {
            if (chats.get(i).getCustomerId().equals(customer.getUserId())) {
                s += chats.get(i).getChatText() + "\n";
            }
        }

        area.setText(s);
    }
}

class AgentFrame extends JFrame {
    private SupportAgent agent;
    private JTextArea area;

    public AgentFrame(SupportAgent agent) {
        this.agent = agent;

        setTitle("Support Agent Panel");
        setSize(800, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        area = new JTextArea();
        add(new JScrollPane(area), BorderLayout.CENTER);

        JPanel panel = new JPanel(new GridLayout(2, 4));

        JButton openButton = new JButton("Open Tickets");
        JButton sortedButton = new JButton("Sorted Tickets");
        JButton statusButton = new JButton("Change Status");
        JButton answerButton = new JButton("Answer Ticket");
        JButton chatButton = new JButton("Answer Chat");
        JButton historyButton = new JButton("My Chats");
        JButton searchButton = new JButton("Search");
        JButton logoutButton = new JButton("Logout");

        panel.add(openButton);
        panel.add(sortedButton);
        panel.add(statusButton);
        panel.add(answerButton);
        panel.add(chatButton);
        panel.add(historyButton);
        panel.add(searchButton);
        panel.add(logoutButton);

        add(panel, BorderLayout.SOUTH);

        openButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showOpenTickets();
            }
        });

        sortedButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showSortedTickets();
            }
        });

        statusButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                changeStatus();
            }
        });

        answerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                answerTicket();
            }
        });

        chatButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                answerChat();
            }
        });

        historyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showMyChats();
            }
        });

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchTickets();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });
    }

    private void showOpenTickets() {
        String s = "";
        ArrayList<Ticket> tickets = DataStore.ticketManager.getTickets();

        for (int i = 0; i < tickets.size(); i++) {
            if (!tickets.get(i).getStatus().equals("CLOSED")) {
                s += tickets.get(i).toString(tickets) + "\n";
            }
        }

        area.setText(s);
    }

    private void showSortedTickets() {
        String s = "";
        ArrayList<Ticket> list = DataStore.ticketManager.sortByPriority();

        for (int i = 0; i < list.size(); i++) {
            s += list.get(i).toString(DataStore.ticketManager.getTickets()) + "\n";
        }

        area.setText(s);
    }

    private void changeStatus() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Ticket ID"));
            String[] statuses = {"OPEN", "IN_PROGRESS", "ANSWERED", "CLOSED"};
            String status = (String) JOptionPane.showInputDialog(this, "Status", "Status", JOptionPane.QUESTION_MESSAGE, null, statuses, statuses[0]);

            DataStore.ticketManager.changeStatus(id, status);

            if (status.equals("CLOSED")) {
                agent.addClosedTicket();
            }

            JOptionPane.showMessageDialog(this, "Status changed");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void answerTicket() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Ticket ID"));
            String answer = JOptionPane.showInputDialog(this, "Answer");
            DataStore.ticketManager.answerTicket(id, answer, agent);
            JOptionPane.showMessageDialog(this, "Answer saved");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void answerChat() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Chat ID"));
            ChatSession chat = DataStore.chatManager.findChat(id);

            if (chat == null) {
                throw new Exception("Chat not found");
            }

            String text = JOptionPane.showInputDialog(this, "Message");
            DataStore.chatManager.addMessage(id, agent.getUserId(), chat.getCustomerId(), text);
            JOptionPane.showMessageDialog(this, "Message sent");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void showMyChats() {
        String s = "";
        ArrayList<ChatSession> chats = DataStore.chatManager.getChats();

        for (int i = 0; i < chats.size(); i++) {
            if (chats.get(i).getSupportAgentId().equals(agent.getUserId())) {
                s += chats.get(i).getChatText() + "\n";
            }
        }

        area.setText(s);
    }

    private void searchTickets() {
        String word = JOptionPane.showInputDialog(this, "Search word");
        ArrayList<Ticket> list = DataStore.ticketManager.search(word);
        String s = "";

        for (int i = 0; i < list.size(); i++) {
            s += list.get(i).toString(DataStore.ticketManager.getTickets()) + "\n";
        }

        area.setText(s);
    }
}

class AdminFrame extends JFrame {
    private Admin admin;
    private JTextArea area;

    public AdminFrame(Admin admin) {
        this.admin = admin;

        setTitle("Admin Panel");
        setSize(850, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        area = new JTextArea();
        add(new JScrollPane(area), BorderLayout.CENTER);

        JPanel panel = new JPanel(new GridLayout(2, 4));

        JButton usersButton = new JButton("All Users");
        JButton ticketsButton = new JButton("All Tickets");
        JButton chatsButton = new JButton("All Chats");
        JButton dashboardButton = new JButton("Dashboard");
        JButton riskButton = new JButton("Risk Customer");
        JButton supportButton = new JButton("Support Report");
        JButton criticalButton = new JButton("Critical Ticket");
        JButton logoutButton = new JButton("Logout");

        panel.add(usersButton);
        panel.add(ticketsButton);
        panel.add(chatsButton);
        panel.add(dashboardButton);
        panel.add(riskButton);
        panel.add(supportButton);
        panel.add(criticalButton);
        panel.add(logoutButton);

        add(panel, BorderLayout.SOUTH);

        usersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                area.setText(DataStore.dashboardManager.allUsers());
            }
        });

        ticketsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAllTickets();
            }
        });

        chatsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAllChats();
            }
        });

        dashboardButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                area.setText(DataStore.dashboardManager.ticketReport() + "\n" + DataStore.dashboardManager.chatReport());
            }
        });

        riskButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                area.setText("High risk customer:\n" + DataStore.dashboardManager.highRiskCustomer());
            }
        });

        supportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                area.setText(DataStore.dashboardManager.supportReport());
            }
        });

        criticalButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Ticket t = DataStore.ticketManager.findCriticalTicket();
                if (t == null) {
                    area.setText("No ticket");
                } else {
                    area.setText(t.toString(DataStore.ticketManager.getTickets()));
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });
    }

    private void showAllTickets() {
        String s = "";
        ArrayList<Ticket> tickets = DataStore.ticketManager.getTickets();

        for (int i = 0; i < tickets.size(); i++) {
            s += tickets.get(i).toString(tickets) + "\n";
        }

        area.setText(s);
    }

    private void showAllChats() {
        String s = "";
        ArrayList<ChatSession> chats = DataStore.chatManager.getChats();

        for (int i = 0; i < chats.size(); i++) {
            s += chats.get(i).getChatText() + "\n";
        }

        area.setText(s);
    }
}

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame().setVisible(true);
            }
        });
    }
}
//Made by "Alireza Koul 40433853" & "Mehdi Allahdad 40416023" & "Yasin Amiri 40416183" & "Amir Hossein Kany 40421973"